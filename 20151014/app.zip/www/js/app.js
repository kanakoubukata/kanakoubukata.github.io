// cloudantの資格情報
var username = "7edb262b-e968-4320-9585-4b9f4b75d9ba-bluemix";
var password = "3010b31fb0d927d4904086f20f6628da6fb19e97be59a44eee1d86e2cece8d90";
var baseUrl = "https://" + username + ".cloudant.com/report/";
var address = "";

// 初期化処理
ons.bootstrap();
ons.ready(function () {
	// 現在地を取得
	navigator.geolocation.getCurrentPosition(
		function(position) {
			// 取得完了時処理
			var latitude = position.coords.latitude;
			var longitude = position.coords.longitude;
			var geo = new google.maps.Geocoder();
			var param = {location: new google.maps.LatLng(latitude, longitude)};
			// ジオコーディング
			geo.geocode(param, function(result) {
			    address = result[0].formatted_address;
			});
		}, 
		function(error) {
			// 取得失敗時処理
			address = "位置情報未設定";
		}
	);
});

// 一覧ページの初期処理
$(document).on('pageinit', '#list-page', function () {
    // 新規作成アイコンを押した時の処理
    $('.add-btn', this).on('click', function () {
        navi.pushPage('new.html');
    });
    showAllItem();
});

// 追加ページ初期処理
$(document).on('pageinit', '#new-page', function () {
	// 写真を撮るボタン
    $("#photo-btn").on("click", function(){
        var options = {
            quality: 50,  // 画質
            destinationType: Camera.DestinationType.DATA_URL,  // base64で取得
            sourceType:Camera.PictureSourceType.CAMERA,   // 撮影モード
            saveToPhotoAlbum: true   // 撮影後端末に保存
        };
              
        // カメラを起動
        navigator.camera.getPicture(
        	function (base64){
        		// 撮影完了時処理
            	$("#small-image").attr("src", "data:image/jpeg;base64," + base64);
            	$("#photo-btn").attr("disabled", "disabled");
            	$("#add-save-btn").removeAttr("disabled");
        	}, 
        	function (message){
        		// 撮影失敗・キャンセル時処理
            	alert("エラー: " + message);
        	}, 
        	options
        );
    });
    
    // 登録ボタンを押した時の処理
    $('#add-save-btn').on('click', function () {
    	var imgData = $("#small-image").attr("src").replace("data:image/jpeg;base64,","");
        if(!imgData) return;
        $("#add-save-btn").attr("disabled", "disabled");
        
        var date = new Date();
	    var today = date.getFullYear() + "/" + zeroPad((date.getMonth()+1)) + "/" + zeroPad(date.getDate()) + " " + zeroPad(date.getHours()) + ":" + zeroPad(date.getMinutes()) + ":" + zeroPad(date.getSeconds());
        
        var item = {
        	DATE: today,
	        LOCATION: address,
	        _attachments:
			{
		    	PHOTO:
		    	{
		      		content_type:"image/jpeg",
		      		data: imgData
				}
			}
  		};
        // cloudantにデータ登録
        $.ajax({
    		type: "POST",
    		url: baseUrl,
    		username: username,
			password: password,
    		contentType: "application/json",
            data: JSON.stringify(item)
    	}).done(function(result) {
    		alert("登録が完了しました");
    		showAllItem();
            navi.popPage();
    	}).fail(function(error) {
    		alert("エラー：" + error.statusText);
    	});
    });
});

// 一覧データを表示する
function showAllItem() {
    // モーダル画面を表示
    //modal.show();
    // リストを初期化
    var list = $('#list-page .item-list');
    list.empty();

    // 全件取得
   	$.ajax({
		type: "POST",
		url: baseUrl + "_find",
		username: username,
		password: password,
        contentType: "application/json",
	    data: JSON.stringify({
        	"selector": {
				"DATE": {"$ne": null}
			},
           "fields": ["_id", "_rev", "DATE", "LOCATION"],
           "sort": [{"DATE:string":"desc"}]
        })
	}).done(function(data) {
		console.log(data);
		var results = JSON.parse(data);
        // 1件ずつリストに追加する
        results.docs.forEach(function (item) {
            list.append(createListItem(item));
        });
        // 追加した要素群をDOMツリーに組み込む
        ons.compile(list[0]);
	}).fail(function(error) {
		alert("エラー：" + error.statusText);
	}).always(function() {
	    // モーダル画面を消す
        //modal.hide();
	});
}

// １件分のアイテムを表すHTML要素を作成
function createListItem(item) {
    var date = item.DATE;
    var location = item.LOCATION;
    var li = $('#list-item-template .item').clone();
    $('.item-date', li).html(date);
    $('.item-location', li).html(location);
    li.on('click', function () {
        navi.pushPage('detail.html', item);
    });
    return li;
}

// 詳細ページ初期処理
$(document).on('pageinit', '#detail-page', function () {
    // 一覧ページからのパラメータを取得
    var item = navi.getCurrentPage().options;
    $("#small-image").attr("src", baseUrl + item._id + "/PHOTO");
    
    // 削除アイコンを押した時の処理
    $('.del-btn', this).on('click', function () {
        ons.notification.confirm({
            title: '確認',
            message: 'この写真を削除してよろしいですか？',
            callback: function (index) {
                // キャンセルを押されたら終了
                if (!index) return;
                
		        // cloudantのデータ削除
		        $.ajax({
		    		type: "DELETE",
		    		url: baseUrl + item._id + '?rev=' + item._rev,
		    		username: username,
					password: password
		    	}).done(function(result) {
		    		alert("削除が完了しました");
		    		showAllItem();
		            navi.popPage();
		    	}).fail(function(error) {
		    		alert("エラー：" + error.statusText);
		    	});
            }
        });
    });
});

function zeroPad(time) {
	time = time.toString();
	return time.length == 1 ? '0' + time : time;
}